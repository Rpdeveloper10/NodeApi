var express = require('express');
//Create Express app
var app = express();
var bodyParser = require('body-parser');
var multer  = require('multer'); // file Uploade system....

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// parse requests of content-type - application/json
app.use(bodyParser.json());

//#### MySql Connection #############
var mysql = require('MySql');
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "mydb"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to database!!");
});

//File uploade System  ##############
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/images')
    },
    filename: (req, file, cb) => {
      cb(null, file.fieldname + '-' + Date.now()+'.jpg')
    }
});

var upload = multer({storage: storage});
app.post('/fileUpload', upload.single('image'), (req, res, next) => {
    
            res.json({'message': 'File uploaded successfully'});
       
});
// ########### File Uploade End  ##################

//##### Record Insert using Post ################
app.post('/insertuser', function(req, res){
	var name = req.body.name;
	//var newname = name.split(",");
	if(name == ''){
		res.json({
      "message": "name field can not be blank"});
   return false;
	}
	var address =req.body.address;

  //## Query...
  if(name !=undefined && address !=undefined){
  	var sql = "INSERT INTO users (name, address) VALUES ('"+name+"', '"+address+"')";
  	con.query(sql, function (err, result) {
    if (err) throw err;
    console.log(result.affectedRows);
    if (result.affectedRows>0){
    	res.json({
    		name:name,
    		address:address,
    		status:true,
    		"message":"1 Record inserted"});
    }
    else{
    	res.json({
    		name:name,
    		err: err,
    		address:address,
    		status:true,
    		"message":"Oops... record not inserted, try again"});
    }
  });

  } else{
    res.json({
    	"message":"Oops... something went wrong, try again"
    });
  }
});
//#### Insert Query  End ################
 
//#### Get Data Using Get ##############
app.get('/users', function(req, res){
  con.query("SELECT * FROM users ", function (err, result){
    if (err) res.json({
        	status:false,
         /*data:{"ID":result[0].id,"Name":result[0].name,"Address":result[0].address},*/
        	error:err,
    		"message":"Oops something went wrong with query..."
    	});
    if (result.length>0){
        res.json({
        	status:true,
         /*data:{"ID":result[0].id,"Name":result[0].name,"Address":result[0].address},*/
        	Result:result,
    		"message":"your Record Available"
    	});
    }
    else{
    	res.json({
    		"message":"Oops There is No result"
    	});
    }
    	    
  });
});

//#### Get End ###############

//#### Get Data BY ID Using POST ##############
app.post('/userid', function(req, res){
	var id = req.body.id;
  if(id=='' || id==null){ // to check the input id , vailid or Not
    res.json({
    	"message":"Id Can't be blank, please Try Again!!"
    });
   return false; // to hault the code excution when request data not valid
  }
  con.query("SELECT * FROM users WHERE id ='"+id+"'", function (err, result){
    if (err) throw err;
    if (result.length>0){
        res.json({
        	status:true,
         data:{"ID":result[0].id,"Name":result[0].name,"Address":result[0].address},
    		"message":"your Record Available"
    	});
    }
    else{
    	res.json({
    		"message":"Oops There is No result"
    	});
    }
    	    
  });
});
//#### Get BY ID  End ###############

//######## Get By Id Start another Methode (http://localhost:3000/user/5) ########
app.get('/user/:id', function(req, res){
    var id = req.params.id;
    if(id=='' || id==null){ // to check the input id , vailid or Not
    res.json({
    	"message":"Id Can't be blank, please Try Again!!"
    });
   return false; // to hault the code excution when request data not valid
  }
  con.query("SELECT * FROM users WHERE id ='"+id+"'", function (err, result){
    if (err) throw err;
    if (result.length>0){
        res.json({
        	status:true,
         data:{"ID":result[0].id,"Name":result[0].name,"Address":result[0].address},
    		"message":"your Record Available"
    	});
    }
    else{
    	res.json({
    		"message":"Oops There is No result"
    	});
    }
    	    
  });
});
//######## Get By Id Start another Methode END ########

//#### PUT/UPDATE Using POST ################
app.put('/updateuser', function(req, res){
  var id = req.body.id;
  if(id=='' || id==null){ // to check the input id , vailid or Not
    res.json({
    	"message":"Id Can't be blank, please Try Again!!"
    });
   return false; // to hault the code excution when request data not valid
  }
  var name = req.body.name;
  var address = req.body.address;
 //check id in table 
 var sql= "SELECT * FROM users WHERE id = '"+id+"'";
  /*console.log(sql);*/
  con.query(sql, function(err, result){
   if(err) throw err;
   if(result.length>0){  // to check data available or not to update
     var sql = "UPDATE users SET name='"+name+"', address='"+address+"' WHERE id='"+id+"'";
     /*console.log(sql);*/
     con.query(sql, function(req, result){
     res.json({
     	status:true,
     	data:{"ID":id,"Name":name, "Address":address},
     	"message":"Record Updated Successfully!"
           }); 
      });
    }
    else{
    	res.json({
    		"message":"Oops... id does not exists!"
    	});
    }

  });
});
// ######## Put/Update End ##########

//#### Delete Request ############
app.delete('/deleteuser/:id', function(req, res){
   var id = req.params.id;
  if(id=='' || id==null){ // to check the input id , vailid or Not
    res.json({
    	"message":"Id Can't be blank, please Try Again!!"
    });
   return false; // to hault the code excution when request data not valid
  }
   var sql = "DELETE FROM users WHERE id = '"+id+"'";
  con.query(sql, function (err, result) {
    if (err) throw err;
    res.json({
    	status:true,
    	Id:id,
    	"message":"Record is Deleted Successfully!!"
    });
  });
});
//#### Delete End ###########


app.listen (3000, function(req, res){
	console.log('Listen to Port 3000...');
});